<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <style>
        body {
            margin: 0;
            background-color: #FFD700;
        }

        * {
            box-sizing: border-box;
        }

        .hero {
            position: relative;
            background-color: #FFD700;
            height: 50vh;
            background-position: top center;
            background-size: cover;
        }

        .heroText {
            position: absolute;
            color: black;
            text-align: center;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
        }

        h1 {
            font-size: 80px;
            font-weight: 700;
        }

        .contener {
            width: 80%;
            margin-left: auto;
            margin-right: auto;
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 50px;
        }

        .forma {
            display: inline-block;
            flex-basis: 50%;
            width: 49%;
        }

        input {
            width: 100%;
            border-radius: 5px;
            outline: none;
            padding: 10px;
        }

        ::placeholder {
            font-style: bold;
        }

        p {
            font-weight: 700;
            margin-top: 20px;
            margin-bottom: 5px;
        }

        .footer {
            padding: 20px;
            color: white;
            text-align: center;
            background-color: rgb(52, 49, 49);
        }

        span {
            color: red;
            font-size: 20px;
        }




        @media screen and (max-width: 800px) {

            .contener {
                display: block;
                width: 80%;
            }

            .forma {
                width: 100%;
            }

            .hero {
                height: 80px;
            }

            .heroText {
                position: relative;
            }

            h1 {
                font-size: 50px;
                font-weight: 700;
            }

        }

        @media screen and (max-width: 500px) {
            .heroText h1 {
                font-size: 40px;
            }

            .contener {
                display: block;
                width: 90%;
            }
        }
    </style>

</head>

<body>

    <section>
        <div class="hero">
            <div class="heroText">
                <h1>Вие Избравте</h1>
            </div>
        </div>
    </section>

    <div class="contener">
        <div class="forma">
            <label for="nameSurname">
                <p>Име и Презиме</p>
            </label><br />
            <input type="text" name="nameSurname" id="nameSurname" placeholder=" <?php
                                                                                    echo " {$_POST["nameSurname"]} "; ?> " />
        </div>


        <div class="forma">
            <label for="nameSurname">
                <p>Име на компанија</p>
            </label><br />
            <input type="text" name="nameSurname" id="nameSurname" placeholder=" <?php
                                                                                    echo " {$_POST["company"]} "; ?> " />
        </div>

        <div class="forma">
            <label for="nameSurname">
                <p>Контакт имејл</p>
            </label><br />
            <input type="text" name="nameSurname" id="nameSurname" placeholder=" <?php
                                                                                    echo " {$_POST["contactEmail"]} "; ?> " />
        </div>

        <div class="forma">
            <label for="nameSurname">
                <p>Контакт телефон</p>
            </label><br />
            <input type="text" name="nameSurname" id="nameSurname" placeholder=" <?php
                                                                                    echo "{$_POST["tel"]} "; ?> " />
        </div>

        <div class="forma">
            <label for="nameSurname">
                <p>Тип на студии</p>
            </label><br />
            <input type="text" name="nameSurname" id="nameSurname" placeholder=" <?php
                                                                                    echo " {$_POST["academy"]} "; ?> " />
        </div>
    </div>


    </section>
    <footer class="footer">
        <p>Изработено со <span>&#x2764;</span> од студентите на Brainster</p>
    </footer>


</body>

</html>